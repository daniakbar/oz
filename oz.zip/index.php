<?php include 'header.php' ?>
					<div class="slider" id="slider">
						<div class="slItems">

							<div class="slText">
								
								<h1 class="slider-txt">
									<span id="teks1" style="color: #272727; display: inline-block;">#1 HITS</span>
									<span id="teks2" style="display: inline-block;">RADIO</span> 
								 </h1>
								<h1 id="teks3" class="slider-txt" style="display: block;">STATION</h1>
								

							</div>

							<div class="slmouse">
								<span class="scroll-btn" style="bottom: 6em;">
									<a href="#">
										<span class="mouse">
											<span>
											</span>
										</span>
									</a>
								</span>
								
							</div>
							
							<div class="slItem" style="background-image: url('images/is.jpg'); z-index: 0; position: ;">
								
							</div>
							<div class="slItem" style="background-image: url('images/om-bob.jpg');">
								
							</div>
							<div class="slItem" style="background-image: url('images/iwan-fals.jpg');">
				
							</div>
						</div>
					</div>


				</div>
				
			</div>
		</div>
		<!-- SLIDESHOW -->
		
		<div class="divider-page"></div>
		<!-- CONTENT TOP HITS -->
		<!-- =================================================== -->
		<!-- CONTENT -->
		<div id="title" style="background-image: url(images/maxres.jpg);" class="slide-section header parallax-window" data-parallax="scroll" data-image-src="images/maxres.jpg">
		  <div class="image-overlay-black"></div>
		  	<div class="container">
			  	<div class="row box">
				  	<div class="col-md-4">
					  	<div class="box-radius">
					  		<h4><span class="oz-color">#1</span> Martin Garrix & Bebe Rexha</h4>
							<div class="top1">
								<img src="images/maxres.jpg">
							</div>
							<div class="menu-play row">
								<div class="btn-group btn-group-justified" role="group" aria-label="...">
								  <div class="btn-group" role="group">
								    <a href="http://www.joox.com/#/single?id=G1enaDDlmQ+8DYJGK2G6dw==" target="_blank" class="btn">PLAY</a>
								  </div>
								  <div class="btn-group" role="group">
								    <a href="https://itunes.apple.com/us/album/in-the-name-of-love-single/id1137640898" target="_blank" class="btn">BUY</a>
								  </div>
								  <div class="btn-group" role="group">
								    <a href="https://youtu.be/RnBT9uUYb1w" target="_blank" class="btn">VIDEO</a>
								  </div>
								</div>
							</div>
				  		</div>
				  	</div>

					<div class="col-md-5">
						<div class="margin">
				  			<h1 class="hits-text"><span class="ten-txt">#10</span> TOP HITS</h1>
				  			<div class="top-40">
				  				<ul>
				  					<li><a href="#">1. TOP 1</a></li>
				  					<li><a href="#">2. TOP SAMPLE</a></li>
				  					<li><a href="#">3. TOP SAMPLE</a></li>
				  					<li><a href="#">4. TOP SAMPLE</a></li>
				  					<li><a href="#">5. TOP SAMPLE</a></li>
				  					<li><a href="#">6. TOP SAMPLE</a></li>
				  					<li><a href="#">7. TOP SAMPLE</a></li>
				  					<li><a href="#">8. TOP SAMPLE</a></li>
				  					<li><a href="#">9. TOP SAMPLE</a></li>
				  					<li><a href="#">10. TOP SAMPLE</a></li>
				  					<li><a href="#">#40 TOP HITS</a></li>
				  				</ul>
				  			</div>
				  		</div>
				  	</div>

				  	<div class="col-md-3">

				  		<div class="ads no-ads">
				  			<a href="#">
				  				<img src="images/biznet.jpg">
				  			</a>	
				  		</div>

				  		<div class="ads">
				  			<a href="#">
				  				<img src="images/xl.jpg">
				  			</a>	
				  		</div>
				  		
				  	</div>
			   	</div>
			</div>
		</div>

		<div class="divider-page"></div>
		

		<div id="title" style="background-image: url(images/maxres.jpg);" class="slide-section">
		  <div class="image-overlay"></div>
			  <div class="container">
				  	<div class="row box">
					  	<div class="col-md-8">
					  		<img class="logo-body" src="images/logo-panel.png">
					  		<a href="#">
					  			<div class="bg-program">
						  			<img src="images/om-bob.jpg">
						  		</div>
						  		<div class="box-radius program-panel">
						  			<h1 class="hover-title-lg">#PROGRAM</h1>
					  			</div>
					  		</a>
					  	</div>

						<div class="col-md-4">
							<a href="#">
								<div class="bg-ponggawa">
						  			<img src="images/gac.jpg">
						  		</div>
						 		<div class="box-radius ponggawa-panel">
							  		<h1 class="hover-title">#PONGGAWA</h1>
						  		</div>
					  		</a>
					  	</div>
					</div>

					<div class="news-panel">

					  	<div class="col-md-4">
					  		<div class="box-radius pull-left" style=" text-align: left; color: #000;">
						  		<h1 class="bold-txt">#OZ_NEWS</h1>
						  	</div>
					  	</div>

					  	<div class="col-md-4">
					  		<div class="box-radius pull-right" style="float: left; text-align: right;">
						  		<h1>OZ DISCOLAND</h1>
						  		<p class="white"> “Do what you like, and like what you do” Twitter  : @haryojudanto. Bandung, 31</p>
						  	</div>
					  	</div>

					  	<div class="col-md-4">
					  		<div class="box-radius pull-right" style="float: left; margin-left: 10%;">
						  		<a href="#" class="btn btn-oz btn-lg">VIEW MORE</a>
						  	</div>
					  	</div>
 	
					</div>
				</div>
			</div>
		</div>

		<div class="divider-page"></div>

		<div id="slide5-section" class="slide-client header-section">
			<div class="container">
				<h1 class="our-partner">OUR PARTNER<br><small>We help more than 5,000 global clients</small></h1>

			    <div class="client-footer">
			    	
			    	<div class="client-margin">
			    		<img src="images/indomie.png">
			    	</div>
			    	<div class="client-margin">
			    		<img src="images/g.png">
			    	</div>
			    	<div class="client-margin">
			    		<img src="images/sunde-bw.png">
			    	</div>
			    	<div class="client-margin">
			    		<img src="images/fb.png">
			    	</div>
			    	<div class="client-margin">
			    		<img src="images/teh-pucuk.jpg">
			    	</div>

			    </div>
		    </div>
		</div>
		<!-- ==================================================== -->
		<!-- CONTENT -->
<?php include 'footer.php' ?>
		